package rusticpipes.network;

import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.EnergyStorage;
import net.minecraftforge.energy.IEnergyStorage;
import rusticpipes.block.BlockConduit;
import rusticpipes.block.BlockItemPipe;
import rusticpipes.handlers.ForgeConfigHandler;
import rusticpipes.tileentity.TileEntityConduit;

import java.util.*;

/**
 * Shared-buffer conduit network.
 *
 * The entire connected network shares one EnergyStorage. Every conduit TE
 * exposes it via getCapability(ENERGY, side) so generators push in and
 * machines pull out from any point in the network.
 *
 * Each tick the master TE calls tick() which:
 *   1. Measures lastFePerTick for spark effects.
 *   2. Actively pushes buffered FE into adjacent machines that can't pull.
 *   3. Applies optional percentage power loss (voided).
 *
 * Pipe networks draw their own FE directly via PipeNetwork.drainFromConduit().
 * The conduit has no tier concept of its own.
 */
public class ConduitNetwork {

    private static final Map<BlockPos, ConduitNetwork> NETWORKS = new HashMap<>();

    private final Set<BlockPos> members = new HashSet<>();

    /** The single shared energy buffer for this whole network. */
    private EnergyStorage sharedBuffer;

    /** FE delta observed last tick — used for spark effects. */
    private int lastFePerTick = 0;

    /** Snapshot of buffer fill at start of tick — to compute delta. */
    private int bufferAtTickStart = 0;

    public ConduitNetwork() {
        int maxIo = ForgeConfigHandler.conduit.maxFePerTickPerFace;
        sharedBuffer = new EnergyStorage(ForgeConfigHandler.conduit.networkBufferCapacity, maxIo, maxIo);
    }

    /** Recreate the shared buffer preserving stored FE (flat config capacity). */
    private void rebuildBuffer() {
        int cap    = ForgeConfigHandler.conduit.networkBufferCapacity;
        int maxIo  = ForgeConfigHandler.conduit.maxFePerTickPerFace;
        int stored = Math.min(sharedBuffer.getEnergyStored(), cap);
        sharedBuffer = new EnergyStorage(cap, maxIo, maxIo);
        sharedBuffer.receiveEnergy(stored, false);
    }

    /** The shared IEnergyStorage every conduit TE in this network exposes. */
    public IEnergyStorage getSharedStorage() {
        return sharedBuffer;
    }

    // -----------------------------------------------------------------------
    // Static network management
    // -----------------------------------------------------------------------

    public static ConduitNetwork getNetwork(BlockPos pos) {
        return NETWORKS.get(pos);
    }

    public static void onConduitAdded(World world, BlockPos pos) {
        Set<ConduitNetwork> neighbours = new HashSet<>();
        for (EnumFacing face : EnumFacing.VALUES) {
            ConduitNetwork n = NETWORKS.get(pos.offset(face));
            if (n != null) neighbours.add(n);
        }

        if (neighbours.isEmpty()) {
            ConduitNetwork network = new ConduitNetwork();
            network.members.add(pos);
            NETWORKS.put(pos, network);
        } else if (neighbours.size() == 1) {
            ConduitNetwork network = neighbours.iterator().next();
            network.members.add(pos);
            NETWORKS.put(pos, network);
            network.rebuildBuffer();
        } else {
            ConduitNetwork kept = neighbours.iterator().next();
            int mergedFe = kept.sharedBuffer.getEnergyStored();
            for (ConduitNetwork other : neighbours) {
                if (other == kept) continue;
                mergedFe += other.sharedBuffer.getEnergyStored();
                for (BlockPos memberPos : other.members) {
                    kept.members.add(memberPos);
                    NETWORKS.put(memberPos, kept);
                }
            }
            kept.members.add(pos);
            NETWORKS.put(pos, kept);
            int cap   = ForgeConfigHandler.conduit.networkBufferCapacity;
            int maxIo = ForgeConfigHandler.conduit.maxFePerTickPerFace;
            kept.sharedBuffer = new EnergyStorage(cap, maxIo, maxIo);
            kept.sharedBuffer.receiveEnergy(Math.min(mergedFe, cap), false);
        }
    }

    public static void onConduitRemoved(World world, BlockPos pos) {
        ConduitNetwork network = NETWORKS.get(pos);
        if (network == null) return;

        NETWORKS.remove(pos);
        network.members.remove(pos);

        if (network.members.isEmpty()) return;

        Set<BlockPos> visited = new HashSet<>();
        Queue<BlockPos> queue = new ArrayDeque<>();
        BlockPos seed = network.members.iterator().next();
        queue.add(seed);
        visited.add(seed);

        while (!queue.isEmpty()) {
            BlockPos current = queue.poll();
            for (EnumFacing face : EnumFacing.VALUES) {
                BlockPos neighbourPos = current.offset(face);
                if (network.members.contains(neighbourPos) && !visited.contains(neighbourPos)) {
                    visited.add(neighbourPos);
                    queue.add(neighbourPos);
                }
            }
        }

        if (visited.size() == network.members.size()) return;

        Set<BlockPos> remaining = new HashSet<>(network.members);
        remaining.removeAll(visited);

        int totalFe    = network.sharedBuffer.getEnergyStored();
        int totalNodes = network.members.size();
        int feA = (totalNodes > 0) ? (totalFe * visited.size()   / totalNodes) : 0;
        int feB = (totalNodes > 0) ? (totalFe * remaining.size() / totalNodes) : 0;

        int maxIo = ForgeConfigHandler.conduit.maxFePerTickPerFace;
        int cap   = ForgeConfigHandler.conduit.networkBufferCapacity;

        network.members.clear();
        network.members.addAll(visited);
        network.sharedBuffer = new EnergyStorage(cap, maxIo, maxIo);
        network.sharedBuffer.receiveEnergy(Math.min(feA, cap), false);
        for (BlockPos memberPos : visited) NETWORKS.put(memberPos, network);

        ConduitNetwork newNetwork = new ConduitNetwork();
        newNetwork.sharedBuffer = new EnergyStorage(cap, maxIo, maxIo);
        newNetwork.sharedBuffer.receiveEnergy(Math.min(feB, cap), false);
        for (BlockPos memberPos : remaining) {
            newNetwork.members.add(memberPos);
            NETWORKS.put(memberPos, newNetwork);
        }
    }

    // -----------------------------------------------------------------------
    // Tick — called from TileEntityConduit (master = smallest BlockPos)
    // -----------------------------------------------------------------------

    public void tick(World world) {
        int stored = sharedBuffer.getEnergyStored();
        lastFePerTick = stored - bufferAtTickStart;
        bufferAtTickStart = stored;

        // Push FE into adjacent machines that cannot pull on their own
        if (stored > 0) {
            for (BlockPos memberPos : members) {
                TileEntity mte = world.getTileEntity(memberPos);
                if (!(mte instanceof TileEntityConduit)) continue;

                for (EnumFacing face : EnumFacing.VALUES) {
                    BlockPos np = memberPos.offset(face);
                    Block nb = world.getBlockState(np).getBlock();
                    if (nb instanceof BlockConduit)  continue;
                    if (nb instanceof BlockItemPipe) continue;

                    TileEntity nte = world.getTileEntity(np);
                    if (nte == null) continue;

                    IEnergyStorage st = nte.getCapability(CapabilityEnergy.ENERGY, face.getOpposite());
                    if (st == null) st = nte.getCapability(CapabilityEnergy.ENERGY, null);
                    if (st == null || !st.canReceive()) continue;

                    int toSend = Math.min(ForgeConfigHandler.conduit.maxFePerTickPerFace,
                            sharedBuffer.getEnergyStored());
                    if (toSend <= 0) break;

                    int accepted = st.receiveEnergy(toSend, false);
                    if (accepted > 0) sharedBuffer.extractEnergy(accepted, false);
                }
            }
        }

        // Power loss — percentage of stored FE per tick, voided
        double lossRate = ForgeConfigHandler.conduit.powerLossPerConduitPerTick;
        if (lossRate > 0.0 && sharedBuffer.getEnergyStored() > 0) {
            int loss = (int) Math.ceil(sharedBuffer.getEnergyStored() * lossRate);
            if (loss > 0) sharedBuffer.extractEnergy(loss, false);
        }
    }

    // -----------------------------------------------------------------------
    // Accessors
    // -----------------------------------------------------------------------

    /** Positive = net gain last tick, negative = net drain. Used for spark effects. */
    public int getLastFePerTick()  { return lastFePerTick; }
    public int getBufferStored()   { return sharedBuffer.getEnergyStored(); }
    public int getBufferCapacity() { return ForgeConfigHandler.conduit.networkBufferCapacity; }
    public Set<BlockPos> getMembers() { return Collections.unmodifiableSet(members); }
    public int getMemberCount()    { return members.size(); }
}
